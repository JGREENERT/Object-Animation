README: Keyboard Controls

Select Object:
Camera = c
Merry Go Round = m
Light Post = l
Light Post Light = 1
Moon = 0
Rain = Not Implemented (Each Raindrop has its own CF, that's a lot of CF's)

Rotate Object:
Shift + Arrow Keys (Use combination of Up/Down and Left/Right to move along Z-Axis)
Mouse Click (Rotates horizontally around object)

Translate Object:
X = X-Axis
Y = Y-Axis
Z = Z-Axis

Object Zoom:
Mouse Scroll (Zooms towards or away from object)

Add Wind:
S, D, Shift + S, Shift + D

Increase/Decrease Rain Fall Speed:
f = Decrease 
g = Increase 

Light Switches:
Light Post = l
Light Post Light = 1
Moon = 0

Object Animation Timer:
t = set timer for a 10 second animation

Pause Animation:
Space Bar
