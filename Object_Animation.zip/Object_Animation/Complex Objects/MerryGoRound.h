#include <vector>
#include "../Simple Objects/Cylinder.h"
#include "../Simple Objects/Torus.h"
using namespace std;

class MerryGoRound{
public:
    ~MerryGoRound();
    void build();
    void render()const;
};