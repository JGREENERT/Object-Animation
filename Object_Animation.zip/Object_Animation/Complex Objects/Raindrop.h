#include <vector>
#include "../Simple Objects/Cylinder.h"
using namespace std;

class Raindrop{
public:
    ~Raindrop();
    void build();
    void render()const;
};